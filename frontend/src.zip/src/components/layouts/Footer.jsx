import React from 'react'
// import "./App.css";

const Footer = () => {
  return (
    <>
    <footer>
        <p className="text-center">
            Food Delivery Website - 2024. All Rights Reserved By Chitra Banu
        </p>
    </footer>
      
    </>
  )
}

export default Footer
